import React from "react";
import { render, screen } from "@testing-library/react";
import Navbar from "./Navbar";
import { MemoryRouter } from "react-router-dom";

describe("Navbar component", () => {
  test("renders EEG Data Reader link", () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    const eegDataReaderLink = screen.getByText("EEG Data Reader");
    expect(eegDataReaderLink).toBeInTheDocument();
  });

  test("renders Home link", () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    const homeLink = screen.getByText("Home");
    expect(homeLink).toBeInTheDocument();
  });

  test("renders Avatar link", () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    const avatarLink = screen.getByText("Avatar");
    expect(avatarLink).toBeInTheDocument();
  });

  test("navigates to correct route when Home link is clicked", () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    const homeLink = screen.getByText("Home");
    userEvent.click(homeLink);
    expect(window.location.pathname).toBe("/");
  });

  test("navigates to correct route when Avatar link is clicked", () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    const avatarLink = screen.getByText("Avatar");
    userEvent.click(avatarLink);
    expect(window.location.pathname).toBe("/avatar");
  });
});
