import React from "react";
import { render, screen } from "@testing-library/react";
import Navbar from "./Navbar";

describe("Navbar Component", () => {
  test("renders Navbar component", () => {
    render(<Navbar />);
    const navbarElement = screen.getByTestId("navbar");
    expect(navbarElement).toBeInTheDocument();
  });

  test("renders EEG Data Reader link", () => {
    render(<Navbar />);
    const eegDataReaderLink = screen.getByText("EEG Data Reader");
    expect(eegDataReaderLink).toBeInTheDocument();
  });

  test("renders Home link", () => {
    render(<Navbar />);
    const homeLink = screen.getByText("Home");
    expect(homeLink).toBeInTheDocument();
  });

  test("renders Avatar link", () => {
    render(<Navbar />);
    const avatarLink = screen.getByText("Avatar");
    expect(avatarLink).toBeInTheDocument();
  });
});
